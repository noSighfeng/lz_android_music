package com.example.androidwork.pojo;

public class Creator {

    String  nickname;

    String  backgroundUrl;

    String  avatarUrl;

}
