package com.example.androidwork.adapter;

import android.content.Context;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.example.androidwork.Bean.HomeListBean;
import com.example.androidwork.R;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class HomeMultiAdapter extends BaseMultiItemQuickAdapter<HomeListBean, BaseViewHolder> {



    public HomeMultiAdapter( @Nullable List<HomeListBean> data) {
        super(data);
        addItemType(HomeListBean.icon, R.layout.item_home_icon);
        addItemType(HomeListBean.recommend,R.layout.item_home_recommend);
        addItemType(HomeListBean.dailySongs,R.layout.item_home_daily_songs);

    }

    @Override
    protected void convert(@NotNull BaseViewHolder baseViewHolder, HomeListBean homeListBean) {
        switch (baseViewHolder.getItemViewType()){
            case HomeListBean.icon:
                initIconView(baseViewHolder,homeListBean);
                break;
            case HomeListBean.recommend:
                break;
            case HomeListBean.dailySongs:
                break;
        }
    }

    void initIconView(BaseViewHolder baseViewHolder,HomeListBean homeListBean){


        RecyclerView recyclerView = baseViewHolder.getView(R.id.home_recycler_view);
        final LinearLayoutManager manager = new LinearLayoutManager(getContext());
        manager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(manager);

    }
}
