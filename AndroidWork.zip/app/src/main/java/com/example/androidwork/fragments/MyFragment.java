package com.example.androidwork.fragments;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.example.androidwork.R;
import com.example.androidwork.adapter.PlayListAdapter;
import com.example.androidwork.http.MyRetrofit;
import com.example.androidwork.pojo.Play;
import com.example.androidwork.pojo.PlayList;
import com.google.android.material.imageview.ShapeableImageView;
import org.jetbrains.annotations.NotNull;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.ArrayList;
import java.util.List;

public class MyFragment extends Fragment {

    private View view;
    private LinearLayout topBar, myLinear;

    private ShapeableImageView avatar;

    private View loginView, likeView;

    private PlayListAdapter playListAdapter;

    private List<Play> playList = new ArrayList<>();

    private RecyclerView recyclerViewPlayList;
    private Fragment fragment;


    public static MyFragment newInstance(){
        return new MyFragment();
    }

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
//        super.onCreateView(inflater, container, savedInstanceState);


        fragment = this;

        view = inflater.inflate(R.layout.fragment_my, container, false);

        avatar = view.findViewById(R.id.imageView);

        //设置顶部元素背景颜色
        topBar = requireActivity().findViewById(R.id.top_bar);
        topBar.setBackgroundColor(Color.parseColor("#f5f5f5"));

        loginView = view.findViewById(R.id.loginView);
        loginView.setOnHoverListener(null);
        loginView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(fragment).navigate(R.id.action_my_to_login);
            }
        });

        likeView = view.findViewById(R.id.like_view);
        likeView.setOnHoverListener(null);
        likeView.setOnClickListener(new View.OnClickListener() {
            Bundle bundle = new Bundle();

            @Override
            public void onClick(View view) {
                Play play = playList.get(0);
                play.setPicUrl(play.getCoverImgUrl());
                bundle.putSerializable("play",play);
                NavHostFragment.findNavController(fragment).navigate(R.id.action_my_to_like_song, bundle);
            }
        });


        Glide.with(this)
                .load("http://p1.music.126.net/DSLx5e0WitxUGatV7uC-Zw==/109951168724029608.jpg")
                .placeholder(R.drawable.avatar)
                .apply(RequestOptions.bitmapTransform(new CircleCrop()))
                .into(avatar);


//        initAdapter();

        requirePlayList();


        return view;
    }


    public void initAdapter() {

    }


    public void requirePlayList() {
        Call<PlayList> playListCall = MyRetrofit.myApi.getUserPlayList("5057242577");
        playListCall.enqueue(new Callback<PlayList>() {
            @Override
            public void onResponse(Call<PlayList> call, Response<PlayList> response) {
                playList = response.body().getPlaylist();
                recyclerViewPlayList = view.findViewById(R.id.playlist);
                playListAdapter = new PlayListAdapter(R.layout.item_playlist, playList.subList(1,playList.size()));
                recyclerViewPlayList.setAdapter(playListAdapter);
                LinearLayoutManager lm = new LinearLayoutManager(getActivity()) {
                    @Override
                    public boolean canScrollVertically() {
                        return false;
                    }
                };
                recyclerViewPlayList.setLayoutManager(lm);
                playListAdapter.setOnItemClickListener(new OnItemClickListener() {
                    @Override
                    public void onItemClick(@NonNull @NotNull BaseQuickAdapter<?, ?> adapter, @NonNull @NotNull View view, int position) {
                        Play play = (Play) adapter.getItem(position);
                        play.setPicUrl(play.getCoverImgUrl());
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("play",play);
                        NavHostFragment.findNavController(fragment).navigate(R.id.action_my_to_like_song, bundle);

                    }
                });


                Glide.with(fragment).asBitmap().load(playList.get(0).getCoverImgUrl()).into(new CustomTarget<Bitmap>() {
                    TextView textView = (TextView) view.findViewById(R.id.like_image);
                    @Override
                    public void onResourceReady(@NonNull @NotNull Bitmap resource, @Nullable @org.jetbrains.annotations.Nullable Transition<? super Bitmap> transition) {
                        Drawable drawable = new BitmapDrawable(getResources(),resource);
                        drawable.setBounds(0,0,57,57);
                        textView.setCompoundDrawables(drawable,null,null,null);
                        textView.invalidate();
                        textView.setText(textView.getText());
                    }

                    @Override
                    public void onLoadCleared(@Nullable @org.jetbrains.annotations.Nullable Drawable placeholder) {

                    }
                });


            }

            @Override
            public void onFailure(Call<PlayList> call, Throwable t) {

            }
        });
    }
}
