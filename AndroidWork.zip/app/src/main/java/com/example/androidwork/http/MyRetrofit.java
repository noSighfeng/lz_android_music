package com.example.androidwork.http;

import com.example.androidwork.Result.ResultData;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MyRetrofit {

    public final static OkHttpClient httpClient = new OkHttpClient.Builder().addInterceptor(new MyInterceptor()).build();

    public final static Retrofit myRetrofit =  new Retrofit.Builder()
            //设置网络请求BaseUrl地址
            .baseUrl("http://172.31.240.1:3000")
            .client(httpClient)
            .addConverterFactory(GsonConverterFactory.create())
            //设置数据解析器
            .build();

    public final static Api myApi = myRetrofit.create(Api.class);

}
