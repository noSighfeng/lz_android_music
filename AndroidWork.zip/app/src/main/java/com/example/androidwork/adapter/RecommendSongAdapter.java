package com.example.androidwork.adapter;

import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.example.androidwork.R;
import com.example.androidwork.pojo.Song;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class RecommendSongAdapter extends BaseQuickAdapter<Song, BaseViewHolder> {
    public RecommendSongAdapter(int layoutResId, @Nullable List<Song> data) {
        super(layoutResId, data);
    }

    @Override
    protected void convert(@NotNull BaseViewHolder baseViewHolder, Song song) {
        Glide.with(getContext())
                .load(song.getAl().getPicUrl())
                .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                .into((ImageView) baseViewHolder
                        .getView(R.id.recommend_song_image));
        baseViewHolder.setText(R.id.recommend_song_name,song.getName());
        baseViewHolder.setText(R.id.recommend_song_description,song.getAr().get(0).getName());
    }
}
