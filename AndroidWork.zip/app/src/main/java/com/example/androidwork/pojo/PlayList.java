package com.example.androidwork.pojo;

import java.util.List;

public class PlayList {

    private List<Play> playlist;

    List<Play> recommend;

    public List<Play> getRecommend() {
        return recommend;
    }

    public void setRecommend(List<Play> recommend) {
        this.recommend = recommend;
    }

    public List<Play> getPlaylist() {
        return playlist;
    }

    public void setPlaylist(List<Play> playlist) {
        this.playlist = playlist;
    }
}
