package com.example.androidwork.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.View;
import androidx.drawerlayout.widget.DrawerLayout;
import com.example.androidwork.R;

public class HiddenNav {


    private Activity mainActivity ;

    private View bottomNavigation;

    private View topBar;
    private DrawerLayout drawerLayout;

    public HiddenNav(Activity mainActivity) {
        this.mainActivity = mainActivity;
    }

    public  void hidden() {
        bottomNavigation = mainActivity.findViewById(R.id.bottom_navigation);
        bottomNavigation.setVisibility(View.GONE);

        topBar = mainActivity.findViewById(R.id.top_bar);
        topBar.setVisibility(View.GONE);

        drawerLayout = mainActivity.findViewById(R.id.drawer_layout);
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
    }

    public  void recover() {
        bottomNavigation.setVisibility(View.VISIBLE);
        topBar.setVisibility(View.VISIBLE);
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
    }

}
