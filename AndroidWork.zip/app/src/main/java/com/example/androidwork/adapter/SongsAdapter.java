package com.example.androidwork.adapter;

import android.content.Context;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;

import com.example.androidwork.R;
import com.example.androidwork.pojo.Song;
import com.example.androidwork.pojo.Songs;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class SongsAdapter extends BaseQuickAdapter<Song, BaseViewHolder> {


    public SongsAdapter(int layoutResId, @Nullable List<Song> data) {
        super(layoutResId, data);
    }

    @Override
    protected void convert(@NotNull BaseViewHolder baseViewHolder, Song song) {
//        baseViewHolder.setText(R.id.)

        baseViewHolder.setText(R.id.sort,Integer.toString(baseViewHolder.getAbsoluteAdapterPosition()+1));

        baseViewHolder.setText(R.id.song_name, song.getName());

        baseViewHolder.setText(R.id.song_description, song.getAr().get(0).getName()+"-"+song.getAl().getName());

    }
}
