package com.example.androidwork.Bean;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.example.androidwork.Result.ResultData;

public class HomeListBean implements MultiItemEntity {

    //图标
    public static final int icon = 1;
    //推荐歌单
    public static final int recommend = 2;
    //推荐歌曲
    public static final int dailySongs = 3;

    private int itemType;


    public HomeListBean(int itemType) {
        this.itemType = itemType;
    }
    @Override
    public int getItemType() {
        return itemType;
    }
    public void setItemType(int itemType) {
        this.itemType = itemType;
    }
}
