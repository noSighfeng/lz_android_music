package com.example.androidwork.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.example.androidwork.R;
import com.example.androidwork.adapter.SongsAdapter;
import com.example.androidwork.http.MyRetrofit;
import com.example.androidwork.pojo.Play;
import com.example.androidwork.pojo.Song;
import com.example.androidwork.pojo.Songs;
import com.example.androidwork.utils.HiddenNav;
import org.jetbrains.annotations.NotNull;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.ArrayList;
import java.util.List;

public class LikeSongFragment extends Fragment {

    private Activity mainActivity;
    private View view;

    private Fragment thisFragment;

    private HiddenNav hiddenNav;

    private SongsAdapter songsAdapter;
    private RecyclerView recyclerViewSong;

    private List<Song> songs = new ArrayList<>();

    public LikeSongFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_like_song, container, false);

        thisFragment = this;

        requireSongsList();


        //布局隐藏
        mainActivity = requireActivity();
        hiddenNav = new HiddenNav(mainActivity);
        hiddenNav.hidden();
        //NavHostFragment.findNavController(this).popBackStack();

        //回退按钮实现
        ImageView imageView = view.findViewById(R.id.back_image);
        imageView.setOnHoverListener(null);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(thisFragment).popBackStack();
//                System.out.println("/?????");
            }
        });

        return view;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        hiddenNav.recover();
    }


    public void requireSongsList() {
        Bundle bundle = getArguments();
        Play play = (Play) bundle.getSerializable("play");

        Glide.with(thisFragment)
                .load(play.getPicUrl())
                .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                .into((ImageView) view.findViewById(R.id.pic_image));

        TextView textView = view.findViewById(R.id.play_name);
        textView.setText(play.getName());


        Call<Songs> songsCall = MyRetrofit.myApi.getPlaylistTrackAll(play.getId().toString(), String.valueOf(1000));
        songsCall.enqueue(new Callback<Songs>() {
            @Override
            public void onResponse(Call<Songs> call, Response<Songs> response) {
                //RecyclerView适配
                recyclerViewSong = view.findViewById(R.id.recyclerViewSongs);//找到RecyclerView控件
                songs = response.body().getSongs();
                songsAdapter = new SongsAdapter(R.layout.item_songs, songs);//实例化适配器



                songsAdapter.setOnItemClickListener(new OnItemClickListener() {
                    @Override
                    public void onItemClick(@NonNull @NotNull BaseQuickAdapter<?, ?> adapter, @NonNull @NotNull View view, int position) {
                        Song song = (Song) adapter.getItem(position);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("song", song);
                        NavHostFragment.findNavController(thisFragment).navigate(R.id.action_song_to_audio, bundle);
                    }
                });

                recyclerViewSong.setAdapter(songsAdapter);//对RecyclerView控件设置适配器

                LinearLayoutManager lm = new LinearLayoutManager(getActivity());
                recyclerViewSong.setLayoutManager(lm);


            }

            @Override
            public void onFailure(Call<Songs> call, Throwable t) {

            }
        });
    }


}