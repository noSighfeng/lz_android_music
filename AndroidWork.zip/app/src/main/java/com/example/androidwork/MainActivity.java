package com.example.androidwork;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.PagerTabStrip;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;
import com.example.androidwork.Result.ResultData;
import com.example.androidwork.adapter.ViewPagerAdapter;
import com.example.androidwork.fragments.*;
import com.example.androidwork.http.Api;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputEditText;
import org.jetbrains.annotations.NotNull;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ViewPager2 viewPager2;
    NavHostFragment navHostFragment;

    NavController navController;

    TextInputEditText textInputEditText;

    Activity activity = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //搜索
        textInputEditText = findViewById(R.id.textInputEditText);

        textInputEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                getSupportFragmentManager().beginTransaction().add(R.id.nav_bottom_fragment,new SearchFragment()).commit();
//                navController.navigate(R.id.action_home_to_search);
            }
        });



        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        initBottomNavigationView();//关联BottomView与底部导航

        drawerLayout.setScrimColor(Color.TRANSPARENT);
        ImageButton imageButton = findViewById(R.id.home_image_button);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(Gravity.LEFT);
            }
        });



        initSideBarView();


//        String htmlName = "Welcome to <b>Android</b>!";
//        TextView t =  findViewById(R.id.textView);
//        Spanned s = HtmlCompat.fromHtml(htmlName, HtmlCompat.FROM_HTML_SEPARATOR_LINE_BREAK_PARAGRAPH);
//        t.setText(s);

    }

    @Override
    protected void onStart() {
        super.onStart();
//        initPage();
    }

    private void initPage() {
        List<Fragment> fragments = new ArrayList<>();

        FragmentManager manager = navHostFragment.getChildFragmentManager();

        List<Fragment> tt = navHostFragment.getChildFragmentManager().getFragments();
        fragments.add(navHostFragment.getChildFragmentManager().getFragments().get(0));
        fragments.add(navHostFragment.getChildFragmentManager().getFragments().get(0));
//        fragments.add(navHostFragment.getChildFragmentManager().getFragments().get(2));
//        fragments.add(navHostFragment.getChildFragmentManager().getFragments().get(3));


        viewPager2 = findViewById(R.id.view_page2);
        viewPager2.setAdapter(new ViewPagerAdapter(getSupportFragmentManager(),
                getLifecycle(),fragments));
    }


    protected void initBottomNavigationView(){



        //获取FragmentContainerView，并得到其NavController
        navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_bottom_fragment);



        navController = navHostFragment.getNavController();
        //获取BottomNavigationView
        BottomNavigationView navigationView = findViewById(R.id.bottom_navigation);
        navigationView.setItemIconTintList(null);
        navigationView.setItemTextColor(null);

        //关联
        NavigationUI.setupWithNavController(navigationView, navController);

//        NavigationUI.setupActionBarWithNavController(this,navController);

    }

    @Override
    public boolean onSupportNavigateUp() {
        return navController.navigateUp();

    }


    protected void initSideBarView(){

        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_bottom_fragment);
        NavController navController = navHostFragment.getNavController();
        NavigationView navView = findViewById(R.id.nav_side_view);
        NavigationUI.setupWithNavController(navView, navController);


    }


}