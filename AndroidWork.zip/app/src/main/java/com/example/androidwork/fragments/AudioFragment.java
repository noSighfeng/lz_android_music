package com.example.androidwork.fragments;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.androidwork.R;
import com.example.androidwork.Result.ResultData;
import com.example.androidwork.http.MyRetrofit;
import com.example.androidwork.pojo.Song;
import com.google.gson.internal.LinkedTreeMap;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.TreeMap;

public class AudioFragment extends Fragment {

    private View view;

    MediaPlayer mediaPlayer = new MediaPlayer();
    String Url;

    Fragment fragment = this;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
      view = inflater.inflate(R.layout.fragment_audio, container, false);

      Bundle bundle = getArguments();
        assert bundle != null;
        Song song = (Song) bundle.getSerializable("song");
        Call<ResultData> songUrl = MyRetrofit.myApi.getSongUrl(song.getId().toString(),"exhigh");
        songUrl.enqueue(new Callback<ResultData>() {
            @Override
            public void onResponse(Call<ResultData> call, Response<ResultData> response) {
                ArrayList data = (ArrayList) response.body().getData();
                LinkedTreeMap linkedTreeMap = (LinkedTreeMap) data.get(0);
                Url = (String) linkedTreeMap.get("url");
                TextView textView = view.findViewById(R.id.audio_name);
                textView.setText(song.getName());
                try {
                    mediaPlayer.setDataSource(Url);
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

            }

            @Override
            public void onFailure(Call<ResultData> call, Throwable t) {

            }
        });


        return view;
    }


}