package com.example.androidwork.fragments;

import androidx.fragment.app.Fragment;
import com.example.androidwork.R;

public class BottomNavigationBar extends Fragment {
    public BottomNavigationBar() {

    }
}
