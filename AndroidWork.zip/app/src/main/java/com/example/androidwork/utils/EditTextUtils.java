package com.example.androidwork.utils;

import android.widget.EditText;

public class EditTextUtils {

    public static Boolean isTextEmpty(EditText editText){
        return editText.getText().toString().equals("");
    }
}
