package com.example.androidwork.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.example.androidwork.R;
import com.example.androidwork.Result.ResultData;
import com.example.androidwork.adapter.IconAdapter;
import com.example.androidwork.adapter.RecommendAdapter;
import com.example.androidwork.adapter.RecommendSongAdapter;
import com.example.androidwork.http.MyRetrofit;
import com.example.androidwork.pojo.*;
import com.youth.banner.Banner;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import com.youth.banner.indicator.CircleIndicator;
import org.jetbrains.annotations.NotNull;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class HomeFragment extends Fragment {

    //    public HomeFragment() {
//        super(R.layout.fragment_home);
//    }
    private final Retrofit retrofit = MyRetrofit.myRetrofit;
    View view;
    List<String> bannerList = new ArrayList<>();
    Fragment fragment = this;
    List<icon> iconData;
    private LinearLayout topBar;

    int i = 1;

    public static HomeFragment newInstance() {
        HomeFragment homeFragment = new HomeFragment();
        return homeFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        super.onCreateView(inflater, container, savedInstanceState);
        view = inflater.inflate(R.layout.fragment_home, container, false);

        topBar = requireActivity().findViewById(R.id.top_bar);
        topBar.setBackgroundColor(Color.parseColor("#ffffff"));



        System.out.println(i);
        i++;
        //加载轮播图
        initBanner();
        //加载图标
        initIcon();
        //加载推荐歌单
        initRecommend();
        //加载推荐歌曲
        initRecommendSong();
        return view;

    }

    public void initIcon() {
        if (!Objects.isNull(iconData) && iconData.size() > 0){
            System.out.println("????"  );
            return;
        }
        Call<ResultData<List<icon>>> call = MyRetrofit.myApi.getHomepageIcon();
        System.out.println("dsdad");
        call.enqueue(new Callback<ResultData<List<icon>>>() {
            @Override
            public void onResponse(Call<ResultData<List<icon>>> call, Response<ResultData<List<icon>>> response) {
                iconData = response.body().getData();
                RecyclerView recyclerView = view.findViewById(R.id.home_recycler_view);
                IconAdapter iconAdapter = new IconAdapter(R.layout.item_home_icon, iconData);
                LinearLayoutManager lm = new LinearLayoutManager(getActivity());
                lm.setOrientation(LinearLayoutManager.HORIZONTAL);
                recyclerView.setLayoutManager(lm);
                recyclerView.setAdapter(iconAdapter);
//                }

            }

            @Override
            public void onFailure(Call<ResultData<List<icon>>> call, Throwable t) {

            }
        });
    }

    List<Play> playList = new ArrayList<>();
    public void initRecommend() {
        //if (!playList.isEmpty()) return ;
        Call<PlayList> recommendResource = MyRetrofit.myApi.getRecommendResource();
        recommendResource.enqueue(new Callback<PlayList>() {
            @Override
            public void onResponse(Call<PlayList> call, Response<PlayList> response) {

                playList = response.body().getRecommend().subList(1,6);
                Collections.shuffle(playList);
                RecyclerView recyclerView = view.findViewById(R.id.home_recycler_view2);
                RecommendAdapter recommendAdapter = new RecommendAdapter(R.layout.item_home_recommend,playList);
                LinearLayoutManager lm = new LinearLayoutManager(getActivity());
                lm.setOrientation(LinearLayoutManager.HORIZONTAL);
                recommendAdapter.setOnItemClickListener(new OnItemClickListener() {
                    Bundle bundle;
                    @Override
                    public void onItemClick(@NonNull @NotNull BaseQuickAdapter<?, ?> adapter, @NonNull @NotNull View view, int position) {
                        Play play = (Play) adapter.getItem(position);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("play",play);
//                        bundle.putString("id", play.getId().toString());
                        NavHostFragment.findNavController(fragment).navigate(R.id.action_home_to_like_song, bundle);
                    }
                });
                recyclerView.setLayoutManager(lm);
                recyclerView.setAdapter(recommendAdapter);
            }

            @Override
            public void onFailure(Call<PlayList> call, Throwable t) {

            }
        });
    }

    List<Song> songList;

    public  void initRecommendSong(){
        Call<ResultData<Songs>> recommendSongs = MyRetrofit.myApi.getRecommendSongs();
        recommendSongs.enqueue(new Callback<ResultData<Songs>>() {
            @Override
            public void onResponse(Call<ResultData<Songs>> call, Response<ResultData<Songs>> response) {
                songList = response.body().getData().getDailySongs();
                Collections.shuffle(songList);
                RecyclerView recyclerView = view.findViewById(R.id.home_recycler_view3);
                RecommendSongAdapter recommendAdapter = new RecommendSongAdapter(R.layout.item_home_daily_songs,songList);
                GridLayoutManager lm = new GridLayoutManager(getContext(),4,LinearLayoutManager.HORIZONTAL, false);
                recommendAdapter.setOnItemClickListener(new OnItemClickListener() {
                    @Override
                    public void onItemClick(@NonNull @NotNull BaseQuickAdapter<?, ?> adapter, @NonNull @NotNull View view, int position) {
                        Song song = (Song) adapter.getItem(position);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("song",song);
                        NavHostFragment.findNavController(fragment).navigate(R.id.action_home_to_audio,bundle);
                    }
                });
//                lm.setOrientation(LinearLayoutManager.HORIZONTAL);
                recyclerView.setLayoutManager(lm);
                recyclerView.setAdapter(recommendAdapter);
            }

            @Override
            public void onFailure(Call<ResultData<Songs>> call, Throwable t) {

            }
        });
    }

    public void initBanner() {
        bannerList.clear();
        bannerList.add("http://p1.music.126.net/bFVDwbd6SdbzSWJ8Zplkow==/109951168738178368.jpg");
        bannerList.add("http://p1.music.126.net/2lSeLdlgndO_quPxkuw_LQ==/109951168737941264.jpg");
        bannerList.add("http://p1.music.126.net/dayMfUeU1Z0cwnGIpiop-Q==/109951168738150324.jpg");
        bannerList.add("http://p1.music.126.net/k9NnPzgLE34NVXLbGgv0PQ==/109951168738170553.jpg");
        bannerList.add("http://p1.music.126.net/upTvbE5RNQ1oruzHv0wcAw==/109951168738140497.jpg");

        Banner banner;
        banner = view.findViewById(R.id.banner);
        banner.setAdapter(new BannerImageAdapter<String>(bannerList) {

                    @Override
                    public void onBindView(BannerImageHolder holder, String data, int position, int size) {
                        Glide.with(holder.itemView)
                                .load(data)
                                .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                                .into(holder.imageView);

                    }
                }).addBannerLifecycleObserver(this)//添加生命周期观察者
                .setIndicator(new CircleIndicator(getContext()));
    }
}
