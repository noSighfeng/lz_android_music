package com.example.androidwork.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import com.example.androidwork.Bean.MyCookie;
import com.example.androidwork.R;
import com.example.androidwork.Result.ResultData;
import com.example.androidwork.http.MyRetrofit;
import com.example.androidwork.utils.EditTextUtils;
import com.example.androidwork.utils.HiddenNav;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.internal.LinkedTreeMap;
import org.jetbrains.annotations.NotNull;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class LoginPageFragment extends Fragment {

    private String phone;
    private String captcha;

    private Activity mainActivity;
    private View bottomNavigation,topBar;
    private DrawerLayout drawerLayout;

    private Button loginButton;

    private View view;

    private  HiddenNav hiddenNav;

    private Call<ResultData> call;
    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_page_login, container, false);

        mainActivity = requireActivity();
        hiddenNav = new HiddenNav(mainActivity);
        //隐藏bottomNavigation，顶部栏，禁用侧边栏
        hiddenNav.hidden();

        initializeLoginLogic();

        initializeQrLogin();
        return view;
    }

    private void initializeQrLogin() {
        MaterialButton button = view.findViewById(R.id.qr_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View nowView) {
                Call<ResultData> qr = MyRetrofit.myApi.getQrKey();

                qr.enqueue(new Callback<ResultData>() {
                    @Override
                    public void onResponse(Call<ResultData> call, Response<ResultData> response) {
                       LinkedTreeMap map = (LinkedTreeMap) response.body().getData();
                       String key = map.get("unikey").toString();
                        Call<ResultData> qrImg = MyRetrofit.myApi.getQrImg(key,true);
                        qrImg.enqueue(new Callback<ResultData>() {
                            @Override
                            public void onResponse(Call<ResultData> call, Response<ResultData> response) {
                                LinkedTreeMap map = (LinkedTreeMap) response.body().getData();
                                String base64 = map.get("qrimg").toString().split(",")[1];

                                byte[] decodedString = Base64.decode(base64, Base64.DEFAULT);
                                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                                ImageView imageView = view.findViewById(R.id.qr_img);
                                imageView.setImageBitmap(decodedByte);

                                Timer timer = new Timer(true);

                                TimerTask timerTask = new TimerTask() {
                                    @Override
                                    public void run() {
                                        //check qr status
                                        Call<ResultData> check = MyRetrofit.myApi.checkQrStatus(key);
                                        check.enqueue(new Callback<ResultData>() {
                                            @Override
                                            public void onResponse(Call<ResultData> call, Response<ResultData> response) {
                                                if(response.body().getCode()==803){
                                                    MyCookie.cookie = response.body().getCookie();
                                                    timer.cancel();
                                                }

                                            }

                                            @Override
                                            public void onFailure(Call<ResultData> call, Throwable t) {

                                            }
                                        });

                                    }
                                };
                                timer.schedule(timerTask,0,1000);
                            }

                            @Override
                            public void onFailure(Call<ResultData> call, Throwable t) {

                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<ResultData> call, Throwable t) {

                    }
                });
            }
        });
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        hiddenNav.recover();
    }




    Boolean getPhone(){
        EditText phoneEditText = view.findViewById(R.id.phone);
        if(EditTextUtils.isTextEmpty(phoneEditText)){
            Snackbar.make(view, "请输入手机号", Snackbar.LENGTH_SHORT).show();
            return false;
        }
        phone = phoneEditText.getText().toString();
        return true;


    }

    Boolean getCaptcha(){
        EditText captchaEditText = view.findViewById(R.id.captcha);
        if(EditTextUtils.isTextEmpty(captchaEditText)){
            Snackbar.make(view, "请输入验证码", Snackbar.LENGTH_SHORT).show();
            return false;
        }
        captcha = captchaEditText.getText().toString();
        return true;
    }

    public void initializeLoginLogic(){
        loginButton = view.findViewById(R.id.login_button);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (loginButton.getText().equals("点击获取验证码")){
                    if(getPhone()){
                        loginButton.setText("登录");
                        //请求验证码
                        Call<ResultData>call = MyRetrofit.myApi.getCaptcha(phone);
                        call.enqueue(new Callback<ResultData>() {
                            @Override
                            public void onResponse(Call<ResultData> call, Response<ResultData> response) {
                                System.out.println(response.body().getData());
                            }

                            @Override
                            public void onFailure(Call<ResultData> call, Throwable t) {

                            }
                        });
                    }
                }else {
                    if(getCaptcha() && getPhone()){
                        //发送请求登录
                        Call<ResultData>call = MyRetrofit.myApi.verifyCaptcha(phone,captcha);
                        call.enqueue(new Callback<ResultData>() {
                            @Override
                            public void onResponse(Call<ResultData> call, Response<ResultData> response) {
                                System.out.println(response.body().getData());
                                Call<ResultData> refresh = MyRetrofit.myApi.loginRefresh();
                                refresh.enqueue(new Callback<ResultData>() {
                                    @Override
                                    public void onResponse(Call<ResultData> call, Response<ResultData> response) {
                                        System.out.println(response.body().getData());
                                    }

                                    @Override
                                    public void onFailure(Call<ResultData> call, Throwable t) {

                                    }
                                });
                            }

                            @Override
                            public void onFailure(Call<ResultData> call, Throwable t) {

                            }
                        });
                    }
                }
            }
        });
    }
}
