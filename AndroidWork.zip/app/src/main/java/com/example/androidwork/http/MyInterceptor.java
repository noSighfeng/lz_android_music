package com.example.androidwork.http;

import com.example.androidwork.Bean.MyCookie;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

public class MyInterceptor implements Interceptor {

    @NotNull
    @Override
    public Response intercept(@NotNull Chain chain) throws IOException {
        Request request = chain.request();
        HttpUrl oldUrl = request.url();

        HttpUrl modifyUrl =request.url().newBuilder()
//                .addQueryParameter("timestamp", String.valueOf(new Timestamp(new Date().getTime())))
                .addQueryParameter("cookie", MyCookie.cookie)
                .build();

        Request newRequest = request.newBuilder().url(modifyUrl).build();

        return chain.proceed(newRequest);
    }
}
