package com.example.androidwork.pojo;

import java.io.Serializable;
import java.util.List;
import java.util.TreeMap;

public class Song implements Serializable {

    private String name;//歌曲名字

    private Long id;//歌曲id

    private List<Author> ar;

    public List<Author> getAr() {
        return ar;
    }

    public void setAr(List<Author> ar) {
        this.ar = ar;
    }

    private Album al;//专辑

    public Song() {
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Album getAl() {
        return al;
    }

    public void setAl(Album al) {
        this.al = al;
    }
}
