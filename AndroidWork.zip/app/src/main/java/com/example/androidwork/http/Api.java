package com.example.androidwork.http;


import com.example.androidwork.Result.ResultData;

import com.example.androidwork.pojo.PlayList;
import com.example.androidwork.pojo.Song;
import com.example.androidwork.pojo.Songs;
import com.example.androidwork.pojo.icon;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

import java.util.List;

public interface Api {

    @GET("login/qr/key")
    Call<ResultData> getQrKey();

    @GET("login/qr/create")
    Call<ResultData> getQrImg(@Query("key") String key,
                              @Query("qrimg") Boolean qrimg);

    @GET("login/qr/check")
    Call<ResultData> checkQrStatus(@Query("key") String key);

    @GET("captcha/sent")
    Call<ResultData> getCaptcha(@Query("phone") String phone);

    @GET("captcha/verify")
    Call<ResultData> verifyCaptcha(@Query("phone") String phone,@Query("captcha") String captcha);

    @GET("login/refresh")
    Call<ResultData> loginRefresh();

    @GET("login/status")
    Call<ResultData> loginStatus();


    @GET("user/playlist")
    Call<PlayList> getUserPlayList(@Query("uid") String uid);

    @GET("playlist/track/all")
    Call<Songs> getPlaylistTrackAll(@Query("id") String id,@Query("limit") String limit);//获取某个歌单所有歌曲

    @GET("homepage/dragon/ball/rnpage")
    Call<ResultData<List<icon>>> getHomepageIcon();

    @GET("recommend/resource")
    Call<PlayList> getRecommendResource();

    @GET("recommend/songs")
    Call<ResultData<Songs>> getRecommendSongs();

    @GET("song/url/v1")
    Call<ResultData> getSongUrl(@Query("id") String id,@Query("level") String level);


}
