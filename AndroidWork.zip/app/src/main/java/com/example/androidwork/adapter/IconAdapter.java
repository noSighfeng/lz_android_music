package com.example.androidwork.adapter;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;


import android.widget.TextView;
import androidx.annotation.NonNull;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.example.androidwork.R;
import com.example.androidwork.pojo.icon;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class IconAdapter extends BaseQuickAdapter<icon, BaseViewHolder> {
    public IconAdapter(int layoutResId, @Nullable List<icon> data) {
        super(layoutResId, data);
    }

    @Override
    protected void convert(@NotNull BaseViewHolder baseViewHolder, icon icon) {
        Glide.with(getContext()).asBitmap().load(icon.getIconUrl()).into(new CustomTarget<Bitmap>() {
            @Override
            public void onResourceReady(@NonNull @NotNull Bitmap resource, @androidx.annotation.Nullable @org.jetbrains.annotations.Nullable Transition<? super Bitmap> transition) {
                Drawable drawable = new BitmapDrawable(getContext().getResources(),resource);
                drawable.setBounds(0,0,60,60);
                TextView textView = baseViewHolder.getView(R.id.icon_1);
                textView.setCompoundDrawables(null,drawable,null,null);
            }

            @Override
            public void onLoadCleared(@androidx.annotation.Nullable @org.jetbrains.annotations.Nullable Drawable placeholder) {

            }
        });

        baseViewHolder.setText(R.id.icon_1,icon.getName());
    }
}
