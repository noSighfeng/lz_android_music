package com.example.androidwork.http;

import com.example.androidwork.Result.ResultData;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyCallBacks {

    public  class getQrCallBack implements Callback<ResultData>{
        @Override
        public void onResponse(Call<ResultData> call, Response<ResultData> response) {

        }

        @Override
        public void onFailure(Call<ResultData> call, Throwable t) {

        }
    }

}
