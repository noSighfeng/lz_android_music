package com.example.androidwork.pojo;

import java.util.List;

public class Songs {
    private List<Song> songs;

    List<Song> dailySongs;

    public List<Song> getDailySongs() {
        return dailySongs;
    }

    public void setDailySongs(List<Song> dailySongs) {
        this.dailySongs = dailySongs;
    }

    public List<Song> getSongs() {
        return songs;
    }

    public void setSongs(List<Song> songs) {
        this.songs = songs;
    }
}
